# Peer Support Hub (GitHub Pages)

This folder is ready to publish with GitHub Pages.

## Quick Publish (no coding)
1. Create a **public** repo on GitHub (e.g., `peer-support-hub`).
2. Upload **index.html** to the root of the repo.
3. Go to **Settings → Pages**.
   - Source: **Branch = main**, **Folder = / (root)**
   - Click **Save**.
4. After it builds, your site URL will look like:
   `https://YOUR-USERNAME.github.io/peer-support-hub/`

## Add to Home Screen
- **iPhone (Safari):** Share → **Add to Home Screen**
- **Android (Chrome):** ⋮ → **Add to Home Screen**
